  <footer class="main-footer">
    <strong><?=lang('footer_copyright_1');?><?= date('Y'); ?> <?= $settings->sitename; ?>.</strong>
    <?=lang('footer_copyright_2');?>
    <div class="float-right d-none d-sm-inline-block">
      <b><?=lang('footer_version');?></b> <?= $settings->version; ?>
    </div>
  </footer>