
	<hr/>
	<p><i>This email is sent automatically from <a href="<?php echo site_url(); ?>"><?php echo $email_info->from_name; ?></a>.</i></p>

</body>
</html>