@include('buy.common.header')

@yield('content')

@include('buy.common.footer')

@yield('script')

@include('buy.common.footerend')