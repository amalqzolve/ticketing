@extends('common.layout')

@section('content')

<div class="kt-subheader   kt-grid__item" id="kt_subheader">
                            <div class="kt-container  kt-container--fluid ">
                                <div class="kt-subheader__main">
                                    


                                   
                                
                                </div>

                            </div>
                        </div>

    <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
<br/>


                        </div>.




<style type="text/css">
    .hideButton{
       display: none
    }
    .error{
        color: red
    }
</style>
<!--end::Modal-->
@endsection
@section('script')



@endsection
